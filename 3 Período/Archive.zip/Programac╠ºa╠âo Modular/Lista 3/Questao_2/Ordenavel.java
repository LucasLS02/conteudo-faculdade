package Questao_2;

public interface Ordenavel {
	public boolean menorQue(Ordenavel o);
}
