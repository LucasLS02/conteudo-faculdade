package app;

public interface Wakeable {
	
    public void wakeUp();
    
   
    public long ONE_SECOND = 1000;
    public long ONE_MINUTE = 60000;
}

