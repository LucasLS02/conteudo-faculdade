package app;
public class EstendeMostra extends SuperMostra {

	public String str = "estendeStr";

	public void mostra() {
		System.out.println("EstendeMostra :  " + str);
	}
}
