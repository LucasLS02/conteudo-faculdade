package app;
public final class SuperMostra {
	public String str = "superStr";

	public void mostra() {
		System.out.println("SuperMostra:  " + str);
	}
	
}
