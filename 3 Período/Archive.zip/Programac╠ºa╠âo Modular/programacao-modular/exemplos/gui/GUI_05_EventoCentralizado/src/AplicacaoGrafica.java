public class AplicacaoGrafica {
	public static void main(String args[]) {
		JanelaGrafica apg = new JanelaGrafica();
		apg.setVisible(true);
	}
}
