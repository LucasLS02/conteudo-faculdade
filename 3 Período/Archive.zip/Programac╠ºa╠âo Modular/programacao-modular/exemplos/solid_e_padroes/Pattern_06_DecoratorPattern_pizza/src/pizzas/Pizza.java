package pizzas;

public interface Pizza {

	public String getDescricao();
	public double getPreco();
}
