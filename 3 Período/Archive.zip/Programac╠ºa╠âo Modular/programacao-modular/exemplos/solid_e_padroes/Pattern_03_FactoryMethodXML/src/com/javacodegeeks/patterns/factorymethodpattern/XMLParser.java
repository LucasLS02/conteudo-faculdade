package com.javacodegeeks.patterns.factorymethodpattern;

public interface XMLParser {
	
	public String parse();

}
