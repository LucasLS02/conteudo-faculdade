package documentos;

public abstract class Documento {
	public abstract String getDados(); 
}
