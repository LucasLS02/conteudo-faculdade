package documentos;

public class DocumentoTexto extends Documento {
	public String getDados() {
		return "documento texto";
	}
}
