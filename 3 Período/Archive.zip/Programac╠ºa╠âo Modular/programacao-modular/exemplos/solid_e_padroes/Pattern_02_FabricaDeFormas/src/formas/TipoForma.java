package formas;

public enum TipoForma {
	CIRCULO, QUADRADO, RETANGULO;
}
