package formas;

public interface Forma {
	
	void desenhar();

}
