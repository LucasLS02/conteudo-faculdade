public class JatoDeTinta {
	public void imprimir(Documento d, int nrCopias) {
		// Codigo de impressao vai aqui
	}

	public void imprimirDuplicada(Documento d, int nrCopias) {
		// Codigo de impressao vai aqui
	}
}