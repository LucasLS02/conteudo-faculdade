
public class Documento {

}
