public class Laser {
	public void imprimir(Documento d, boolean duplicadas) {
		// Codigo de impressao vai aqui
	}
}