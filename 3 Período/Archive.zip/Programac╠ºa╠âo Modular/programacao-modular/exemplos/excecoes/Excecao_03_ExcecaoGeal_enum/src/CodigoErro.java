
public interface CodigoErro {
	public int getCodigo();
	public int getNumero();
}
