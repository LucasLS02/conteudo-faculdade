# Programação Modular

Material da disciplina de Programação Modular do curso de Engenharia de Software

## Ementa da disciplina

Fatores de qualidade de software. Modularidade. Projeto Orientado para Objetos. Polimorfismo, interfaces, tipos enumeráveis, genéricos e opcionais. Coleções. Tratamento de exceções. Programação Orientada a Eventos. Princípios SOLID. Padrões de projeto. Aspectos funcionais. Desenvolvimento dirigido por testes. Concorrência. Serialização.

## Versão

We use [SemVer](http://semver.org/) for versioning. For the versions available, see the [tags on this repository](https://github.com/your/project/tags). 

## Autor

* **Prof. Hugo de Paula** - *Initial work* - [PurpleBooth](https://github.com/hugodepaula)

## License

Este projeto lé licenciado sob a _Creative Commons Zero v1.0 Universal_  - vejo arquivo a [LICENSE.md](LICENSE) para mais detalhes.


