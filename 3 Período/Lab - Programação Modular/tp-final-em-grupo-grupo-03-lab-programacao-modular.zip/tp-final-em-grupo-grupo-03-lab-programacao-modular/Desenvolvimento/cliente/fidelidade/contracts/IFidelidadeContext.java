package Desenvolvimento.cliente.fidelidade.contracts;

public interface IFidelidadeContext extends IFidelidadeCalculavel {
    public void setFidelidadeState(IFidelidadeState state);
}
