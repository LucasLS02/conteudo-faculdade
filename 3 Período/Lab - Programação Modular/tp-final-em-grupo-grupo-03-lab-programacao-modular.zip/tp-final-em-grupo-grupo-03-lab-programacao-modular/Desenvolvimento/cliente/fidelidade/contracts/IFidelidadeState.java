package Desenvolvimento.cliente.fidelidade.contracts;

public interface IFidelidadeState extends IFidelidadeCalculavel {

    // MARKUP INTERFACE
}
